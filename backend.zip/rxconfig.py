import reflex as rx

config = rx.Config(
    app_name="app_asistencia_reflex",
    plugins=[rx.plugins.TailwindV3Plugin()],
)